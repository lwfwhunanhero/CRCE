####  iteration item
TME <- function(data,Gamma){
  n <- nrow(data); p <- ncol(data)
  M0 <- matrix(0,p,p)
  for(i in 1:n){
    M0 <- M0 + data[i,]%*%t(data[i,])/as.numeric(t(data[i,])%*%ginv(Gamma)%*%data[i,])
  }
  return(M0)
}
#### judge when to stop
stop_distance <- function(A,B){
  p   <- ncol(A)
  pre <- norm(p*B/tr(B) - p*A/tr(A),"F") ### precision deviation
  return(pre)
}
#### Regularized TME
RegTME <- function(data){
  iters <- 0
  n <- nrow(data); p <- ncol(data)
  alpha = max(0, p/n - 1) + 1
  Gamma0 <- alpha/(1 + alpha)*diag(p)
  Gamma1 <- 1/(1+ alpha)*(p/n)*TME(data,Gamma0) + alpha/(1+ alpha)*diag(p)
  while(TRUE){
     iters <- iters + 1
     Gamma0 <- Gamma1
     Gamma1 <- 1/(1+ alpha)*(p/n)*TME(data,Gamma1) + alpha/(1+ alpha)*diag(p)
     d.Gamma <- stop_distance(Gamma0,Gamma1)
     if(is.na(d.Gamma)){  # If the iteration diverges, we return identity matrix
       warning("The iteration diverges!")
       return(diag(1, p))
     }
     if(d.Gamma < 10^(-6) | iters > 1000){
        break
     }
  }
  Gamma <- ncol(Gamma1)*( Gamma1 - alpha/(1+ alpha)*diag(ncol(Gamma1)) ) / tr(Gamma1 - alpha/(1+ alpha)*diag(ncol(Gamma1)))
  return(Gamma)
}
### threshold Gamma
#------------------------------------#
# The step proposed in paper is not the simple soft-threshold
#------------------------------------#
thRegTME <- function(Gamma, lambda){
  Gamma[abs(Gamma)<lambda] <- 0
  Gamma <- sign(Gamma) * (abs(Gamma) - lambda)
  diag(Gamma) <- 1
  return(Gamma)
}
###########################################
### 5-fold CV determines lambda based on sub-clrX matrix
Heavycoat <- function(data, nFolder=5){
  n <- nrow(data)
  p <- ncol(data)
  lower = 0; upper = 10
  nGrid <- 100
  grid  <- lower + (upper - lower)*rep(1:nGrid)/nGrid
  part <- 1 + sample(c(1:n))%%nFolder
  error <- matrix(0, nFolder, nGrid)
  for (i in 1:nFolder){
    xTest  <- data[which(part == i),]
    xTrain <- data[which(part != i),]
    GammaTrain <- RegTME(xTrain)
    covTest <- cov(xTest)*(n-1)/n
    for (j in 1:nGrid){
      sigmaTrain <- thRegTME(GammaTrain,grid[j])
      error[i,j] <- (norm(sigmaTrain-covTest, "F"))
    }
  }
  errorSum <- colSums(error)
  lambda <- grid[which(errorSum == min(errorSum))][1]
  GammaAll <- RegTME(data)
  sigma <- thRegTME(GammaAll,lambda)
  corr <- diag(diag(sigma)^(-0.5))%*%sigma%*%diag(diag(sigma)^(-0.5))
  return(list(sigma = sigma, corr = corr, index.min = which.min(errorSum), lambda = lambda, lambda.max = max(grid)))
}
