require(MASS)
require(Matrix)
require(mvtnorm)
require(LaplacesDemon)
require(distrEllipse)
require(ROCR)

#-----------------------------------------------------------------------------------------------------------
#  Generate correlation matrix
#  Input:
#     p      ------ dimension
#  Output:
#     corr   ------ correlation matrix
#-----------------------------------------------------------------------------------------------------------

# generate banded correlation matrix, the off-diagnal entries is linearly decreasing with speed "dec".
band_corr = function(p, dec=.1){
  band.size = floor(1/dec)
  if(p >= band.size){
    first.row = c(seq(from=1, by=-dec, length=band.size), rep(0, p-band.size))
    corr = toeplitz(first.row)
  }else{
    band.size = p
    first.row = seq(from=1, by=-dec, length=band.size)
    corr = toeplitz(first.row)
  }
  return(corr)
}

# generate correlation matrix with half band and half identity, the off-diagnal entries in the banded one is decreasing with speed "dec".
band_and_identity_corr = function(p, dec=.1){
  p_1 = round(p/2); p_2 = p - p_1
  corr_1 = band_corr(p_1, dec)
  corr_2 = diag(p_2)
  corr = as.matrix(bdiag(corr_1, corr_2))
  return(corr)
}

# generate correlation matrix with 7/10 AR(rho=.7) and 3/10 identity.
AR_and_identity_corr = function(p, rho=.7){
  p_1 = p/10
  corr_1 = toeplitz(rho^(0:(p_1-1)))
  corr_2 = diag(p_1)
  
  mlist <- list()
  for(i in 1:7){
    mlist[[i]] <- corr_1
  }
  for(i in 8:10){
    mlist[[i]] <- corr_2
  }
  corr <- as.matrix(bdiag(mlist))
  return(corr)
}



#-----------------------------------------------------------------------------------------------------------
#  Generate composition data 
#  Input:
#     n      ------ sample size
#     mu     ------ mean of log W
#     corr   ------ covariance of log W
#  Output:
#     x      ------ composition matrix
#     w      ------ count matrix
#-----------------------------------------------------------------------------------------------------------

# Generate composition from multivariate normal distribution (log W is multivariate normal)
generateCompNormal <- function(n, mu, corr){
  logW <- mvrnorm(n = n, mu, corr)
  W <- exp(logW)
  X <- W / rowSums(W)
  return(list(X = X, W = W))
}

# Generate composition from multivariate t distribution (log W is multivariate t)
generateCompT <- function(n, mu, corr, v=5){
  logW <- mvtnorm::rmvt(n, sigma=corr, delta=mu, df=v)
  W <- exp(logW)
  X <- W / rowSums(W)
  return(list(X = X, W = W))
}

# Generate composition with \phi ~ F-distribution 
generateCompF <- function(n, mu, corr, df1 = 2, df2 = 4){
  A = chol(corr)
  ell.object = EllipticalDistribution(radDistr = Fd(df1 = df1, df2 = df2), loc = mu, scale = A)
  logW = t(r(ell.object)(n))
  W <- exp(logW)
  X <- W / rowSums(W)
  return(list(X = X, W = W))
}



#-----------------------------------------------------------------------------------------------------------
#  Generate data
#  Input:
#         n         -------- sample size
#         p        -------- number of variables 
#         modelCov  -------- 1-band cov; 2-band and identity cov; 3-AR and identity cov.
#         DistType -------- 1-normal; 2-t5 distribution; 3-t2.5 distribution; 4-\phi ~ F(2,4)
#         mu       -------- mean vector. If NULL, we set it to be i.i.d. Unif(0, 10).
#  Output:
#     data         -------- data frame (n x p)
#     sigma1       -------- true covariance matrix (p x p)
#-----------------------------------------------------------------------------------------------------------
GenerateData <- function(n, p, modelCov, DistType, mu = NULL){
  # If mu is NULL, we set it to be i.i.d. Unif(0, 10).
  if(is.null(mu)){
    a = 0
    b = 10
    mu <- a + (b-a) * runif(p, 0, 1) 
  }
  
  sigma <- switch (modelCov,
    band_corr(p, dec=.1),
    band_and_identity_corr(p, dec=.1),
    AR_and_identity_corr(p, rho=.7)
  )
  
  XW <- switch (DistType,
    generateCompNormal(n, mu, sigma),
    generateCompT(n, mu, sigma, v=5),
    generateCompT(n, mu, sigma, v=2.5),
    generateCompF(n, mu, sigma, df1=2, df2=4)
  )
  
  return(list(X = XW$X, W = XW$W, sigma = sigma))
}


#---------------------------------------------------------------------------------------------------------
#  Correlation evaluation
#  Input:
#     mat.est   ------ estimation of correlation matrix.
#     mat.true  ------ true correlation matrix.
#  Output:
#     
#---------------------------------------------------------------------------------------------------------
Corr.Evaluate = function(mat.est, mat.true){
  dmat = mat.est - mat.true
  d_l1 = norm(dmat, "o")
  d_S = norm(dmat, "2")
  d_F = norm(dmat, "F")
  
  pred <- prediction(abs(as.vector(mat.est)), abs(as.vector(mat.true)) > 1e-6)
  auc <- unlist(performance(pred, measure = "auc")@y.values)
  
  supp.est = which(abs(as.vector(mat.est)) > 1e-6)
  supp.true = which(abs(as.vector(mat.true)) > 1e-6)
  fpr = length(setdiff(supp.est, supp.true))/max(length(supp.est),1)
  tpr = length(intersect(supp.true, supp.est))/length(supp.true)
  
  res = c(d_l1, d_S, d_F, auc, fpr, tpr)
  res.names = c("l1", "Spectral", "Frobenius", "AUC", "FPR", "TPR")
  return(list(evaluate = res, names = res.names))
}

