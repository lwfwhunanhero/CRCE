#----------------------------------------------------------------------------------------
#  Robust Covariance estimate
#  Input:
#           x ------ n x p composition data matrix (row/column is sample/variable)
#     nFolder ------ number of the foler in cross validation
#        soft ------ soft = 1: soft thresholding; soft = 0: hard thrsholding
#  Output:
#       sigma ------ covariance estimation based on adaptive thresholding 
#        corr ------ correlation estimation based on adaptive thresholding
#        time ------ execution time
#----------------------------------------------------------------------------------------
rcec <- function(x, nFolder = 5, soft = 1){
  startTime <- proc.time()
  p <- ncol(x)
  clrX <- log(x) - rowSums(log(x)) %*%matrix(1,1,p) / p
  rcecPred <- RobustAdaptThresoldCov(clrX, soft = soft)
  sigma <- rcecPred$sigma
  corr <- rcecPred$corr
  exeTimeClass <- proc.time() - startTime
  exeTime <- as.numeric(exeTimeClass[3])
  return(list(sigma = sigma, corr = corr, time = exeTime, index.min = rcecPred$index.min, lambda = rcecPred$lambda, lambda.max = rcecPred$lambda.max))
}
oracle <- function(x, nFolder = 5, soft = 1){
  startTime <- proc.time()
  p <- ncol(x)
  rcecPred <- RobustAdaptThresoldCov(x, soft = soft)
  sigma <- rcecPred$sigma
  corr <- rcecPred$corr
  exeTimeClass <- proc.time() - startTime
  exeTime <- as.numeric(exeTimeClass[3])
  return(list(sigma = sigma, corr = corr, time = exeTime))
}
#----------------------------------------------------------------------------------------
#
# Median of Means (MOM) estimate of the covriance matrix
#
#
#----------------------------------------------------------------------------------------
MOM<- function(x){
  n <- nrow(x)
  p <- ncol(x)
  L <- 1
  M <- ceiling(log(p))  ##### sample size in each block cannot too small
  d <- floor(n/M)
  groupsize <- rep(d,M)+c(rep(1,n-M*d),rep(0,(d+1)*M-n))
  grouplabel <- rep(1:M,groupsize)
  index <- sample(1:n)
  datagroup <- list()
  W <- list()
  mumat <- matrix(0,M,p)
  for(k in 1:M)
  {
    x_k = (x[index[grouplabel==k],,drop=F])
    mumat[k,]=apply(x_k,2,mean)
    W[[k]] <- crossprod(x_k)/groupsize[k]
  }
  mu<-apply(mumat,2,median)
  Gamma<-matrix(apply(sapply(W,c),1,median),p,p)-mu%*%t(mu)
  
  return(Gamma)
}


#----------------------------------------------------------------------------------------
#  Adaptive thresholding estimation of cov(x)
#  Input:
#           x ------ n x p data matrix (row/column is sample/variable)
#     nFolder ------ number of the foler in cross validation
#        soft ------ soft = 1: soft thresholding; soft = 0: hard thrsholding
#  Output:
#       sigma ------ covariance estimation based on adaptive thresholding 
#        corr ------ correlation estimation based on adaptive thresholding 
#----------------------------------------------------------------------------------------
RobustAdaptThresoldCov <- function(x, nFolder = 5, soft = 1){
  n <- nrow(x)
  p <- ncol(x)
  
  # Set the grid for the choice of tuning parameter
  nGrid <- 400
  cov <- MOM(x)
  lower <- 0
  upper <- 40 
  grid <- lower + (upper - lower)*rep(1:nGrid)/nGrid   

  # Multi-folder cross validation
  part <- 1 + sample(c(1:n))%%nFolder
  error <- matrix(0, nFolder, nGrid)
  for (i in 1:nFolder){
    xTest <- x[which(part == i),]
    xTrain <- x[which(part != i),]
    covTest <- MOM(xTest)
    covTrain <- MOM(xTrain)
    for (j in 1:nGrid){
      sigmaTrain <- RobustAdaptThreshold(covTrain,grid[j],soft,xTrain)
      error[i,j] <- (norm(sigmaTrain-covTest, "F"))
    }
  }
  errorSum <- colSums(error)
  lambda <- grid[which(errorSum == min(errorSum))][1]
  sigma <- RobustAdaptThreshold(cov,lambda,soft,x)
  corr <- diag(diag(sigma)^(-0.5))%*%sigma%*%diag(diag(sigma)^(-0.5))
  return(list(sigma = sigma, corr = corr, index.min = which.min(errorSum), lambda = lambda, lambda.max = max(grid)))
}



#----------------------------------------------------------------------------------------
#  Apply adaptive thresholding to the robust covariance estimate
#  Input:
#           cov ------ p x p covariance matrix
#        lambda ------ tuning parameter
#          soft ------ soft = 1: soft thresholding; soft = 0: hard thrsholding
#  Output:
#         sigma ------ p x p matrix, robust adaptive thresholding result
#----------------------------------------------------------------------------------------
RobustAdaptThreshold <- function(cov,lambda,soft,x){
  n <- nrow(x)
  p <- ncol(x)
  covOffDiag <- cov - diag(diag(cov))
  covDiaghalf <- (diag(cov))^0.5
  sigmaTmp <- abs(covOffDiag) - lambda*((log(p)/n)^0.5)*(covDiaghalf%*%t(covDiaghalf))
  sigmaTmp[which(sigmaTmp < 0)] <- 0
  if (soft == 1){
    sigma <- diag(diag(cov)) + sigmaTmp*sign(covOffDiag)
  }else{
    sigma <- cov
    sigma[which(sigmaTmp < 1e-10)] <- 0
    sigma <- sigma + diag(diag(cov))
  }
  return(sigma)
}

