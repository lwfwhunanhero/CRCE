library(fastclime)
library(pcaPP)
library(modelr)
library(compositions)

MyRSclime.s <- function(X, lambda=0.1){
  p <- ncol(X)
  obj <- rep(-1, 2*p)
  S.hat <- cor.fk(X)
  C <- matrix(lambda, nrow=p, ncol=p)
  R <- S.hat + C
  W <- S.hat - C
  mat <- base::rbind(cbind(W,-R), 
                     cbind(-R,W))
  feasible <- TRUE
  Theta.hat <- matrix(ncol=p,nrow=p)
  for(j in 1:p){
    ej <- rep(0, 2*p)
    ej[j] <- 1
    ej[p+j] <- -1
    rhs <- ej
    out.txt <- capture.output(betapm <- fastlp(obj=obj, mat=mat, rhs=rhs))
    if(!grepl("optimal", out.txt) ){
      feasible=FALSE
      break
    }
    Theta.hat[,j] <- betapm[1:p] - betapm[(p+1):(2*p)]
  }
  if(!feasible){
    cat('Theta.hat not found','\n')
  }
  list(Theta.hat=Theta.hat, conv=feasible)
}

#----------------------------------
# Soft thresholding
#----------------------------------
soft.t <- function(Gamma, lambda){
  Gamma[abs(Gamma)<lambda] <- 0
  Gamma <- sign(Gamma) * (abs(Gamma) - lambda)
  diag(Gamma) <- 1
  return(Gamma)
}

#-----------------------------------
# Main function
#------------------------------------
comp.te <- function(X, nGrid=100){
  p <- ncol(X)
  n <- nrow(X)
  
  lower <- 0
  upper <- 0.5
  grid <- lower + (upper - lower)*rep(1:nGrid)/nGrid    
  # cross validation fold
  k <- 5
  
  # cross validation
  cv.error <- matrix(0, k, nGrid)
  crs <- modelr::crossv_kfold(as.data.frame(X), k=k)       
  for(j in 1:k){
    traindata <- X[crs$train[[j]]$idx,]
    testdata <- X[crs$test[[j]]$idx,]
    Gamma.cr <- sin(pi*cor.fk(traindata)/2)
    Sigma.cr <- cor(testdata)
    for(i in 1:length(grid)){
      lambda <- grid[i]
      Sigma.hat <- soft.t(Gamma.cr, lambda)
      cv.error[j, i] <- norm(Sigma.cr - Sigma.hat, "F")
    }
  }
  errorSum <- colSums(cv.error)
  index.min = which.min(errorSum)
  lambda.s <- grid[index.min]
  Gamma <- soft.t(sin(pi*cor.fk(X)/2), lambda.s)
  
  return(list(Gamma=Gamma, index.min=index.min, lambdas=grid))
}


comp.all <- function(X, Y){
  
  tecoat.res <- comp.te(clr(X))
  tecoat.oracle.res <- comp.te(Y)
  
  return(list(corr=tecoat.res$Gamma, corr.o=tecoat.oracle.res$Gamma))
  
}


calTECoatROC <- function(dataCell, sigmaTrue, nPlotPoint = 21, nGrid = 20){
  nRep <- ncol(dataCell)
  plotLength <- 1/(nPlotPoint - 1)
  n <- nrow(dataCell[[1,1]])
  p <- ncol(dataCell[[1,1]])
  TprMat <- matrix(0, nRep, nPlotPoint)
  FprMat <- matrix(0, nRep, nPlotPoint)
  for (i in 1:nRep){
    W <- dataCell[[2,i]]
    X <- dataCell[[1,i]]
    Y <- log(W)
    clrX <- clr(X)
    lower <- 0*sqrt(log(p)/n)
    upper <- 5*sqrt(log(p)/n)
    grid <- lower + (upper - lower)*(rep(1:nGrid)/nGrid)
    corx <- cor.fk(clrX)
    TPR <- matrix(0, nRep, 1)
    FPR <- matrix(0, nRep, 1)
    for (j in 1:nGrid){
      corrHat <- soft.t(corx, grid)
      tprFpr <- calTprFpr(sigmaTrue, corrHat)
      TPR[j] <- tprFpr$tpr
      FPR[j] <- tprFpr$fpr
    }
    for (k in 0:(nPlotPoint-1)){
      TprMat[i, k+1] <- max(TPR[which(FPR < (plotLength/2 + k*plotLength))])
    }
  }
  tprGrid <- colMeans(TprMat)
  fprGrid <- rep(0:(nPlotPoint-1))/(nPlotPoint-1)
  return(list(tprGrid = tprGrid, fprGrid = fprGrid))
}
calTECoatOracleROC <- function(dataCell, sigmaTrue, nPlotPoint = 21, nGrid = 20){
  nRep <- ncol(dataCell)
  plotLength <- 1/(nPlotPoint - 1)
  n <- nrow(dataCell[[1,1]])
  p <- ncol(dataCell[[1,1]])
  TprMat <- matrix(0, nRep, nPlotPoint)
  FprMat <- matrix(0, nRep, nPlotPoint)
  for (i in 1:nRep){
    W <- dataCell[[2,i]]
    Y <- log(W)
    lower <- 0*sqrt(log(p)/n)
    upper <- 5*sqrt(log(p)/n)
    grid <- lower + (upper - lower)*(rep(1:nGrid)/nGrid)
    corx <- cor.fk(Y)
    TPR <- matrix(0, nRep, 1)
    FPR <- matrix(0, nRep, 1)
    for (j in 1:nGrid){
      corrHat <- soft.t(corx, grid)
      tprFpr <- calTprFpr(sigmaTrue, corrHat)
      TPR[j] <- tprFpr$tpr
      FPR[j] <- tprFpr$fpr
    }
    for (k in 0:(nPlotPoint-1)){
      TprMat[i, k+1] <- max(TPR[which(FPR < (plotLength/2 + k*plotLength))])
    }
  }
  tprGrid <- colMeans(TprMat)
  fprGrid <- rep(0:(nPlotPoint-1))/(nPlotPoint-1)
  return(list(tprGrid = tprGrid, fprGrid = fprGrid))
}




