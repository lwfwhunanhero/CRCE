setwd("C:/Users/dell/Desktop/CRCE1005/code")
set.seed(230909)
library(ggplot2)
library(qgraph)
library(SemiPar)
library(Hmisc)
library(mvtnorm)
library(fMultivar)
library(boot)
require(MCMCpack)
require(glmnet)
require(parallel)
require(ROCR)
require(MASS)
require(corpcor)
require(tictoc)
source("generate_functions.R")
source("tecoat.R")
source("heavycoat.R")
source("coat.R")
eps <- 1e-100    # accuracy
soft<-1    # accuracy
df<-read.table("BMIdata.txt",header=T)  # Load the data

# split the data into obese group (BMI >= 25) and lean group (BMI < 25)
df_obese <- df[which(df$BMI >= 25),]
df_lean <- df[which(df$BMI < 25),]

w_obese <- as.matrix(df_obese[,-c(1,2)])
w_lean <- as.matrix(df_lean[,-c(1,2)])

# delete rare taxa
w_obese.binary <- w_obese > 0
w_lean.binary <- w_lean > 0
freq_obese <- colSums(w_obese.binary)
freq_lean <- colSums(w_lean.binary)
w_obese <- w_obese[, -which(freq_obese < 4 | freq_lean < 4)]
w_lean <- w_lean[, -which(freq_obese < 4 | freq_lean < 4)]

# replace zero counts by 0.5
w_obese[which(w_obese == 0)] <- 0.5
w_lean[which(w_lean == 0)] <- 0.5

# convert the count into composition
p <- ncol(w_obese)
x_obese <- w_obese/(rowSums(w_obese)%*%matrix(1,1,p))
x_lean <- w_lean/(rowSums(w_lean)%*%matrix(1,1,p))

##### COAT 
res.coat.obese <- coat(x_obese,nFoler=5)
res.coat.lean <- coat(x_lean,nFoler=5)
coat.ind_true_nonzero.obese <- abs(res.coat.obese$corr - diag(diag(res.coat.obese$corr))) >= eps
coat.ind_true_nonzero.lean <- abs(res.coat.lean$corr - diag(diag(res.coat.lean$corr))) >= eps

##### Heavycoat
#clr0x_obese <- log(x_obese) - rowSums(log(x_obese)) %*%matrix(1,1,p) / p
#clr0x_lean <- log(x_lean) - rowSums(log(x_lean)) %*%matrix(1,1,p) / p
#res.Heavycoat.obese <- Heavycoat(clr0x_obese, nFolder=5) 
#res.Heavycoat.lean <- Heavycoat(clr0x_lean, nFolder=5)
#Heavycoat.ind_true_nonzero.obese <- abs(res.Heavycoat.obese$corr - diag(diag(res.Heavycoat.obese$corr))) >= eps
#Heavycoat.ind_true_nonzero.lean <- abs(res.Heavycoat.lean$corr - diag(diag(res.Heavycoat.lean$corr))) >= eps

##### tecoat
res.tecoat.obese <- comp.te(clr(x_obese))  ## 5 Folder
res.tecoat.lean <- comp.te(clr(x_lean))    ## 5 Folder
tecoat.ind_true_nonzero.obese <- abs(res.tecoat.obese$Gamma - diag(diag(res.tecoat.obese$Gamma))) >= eps
tecoat.ind_true_nonzero.lean <- abs(res.tecoat.lean$Gamma - diag(diag(res.tecoat.lean$Gamma))) >= eps

# bootstraping stability
nRep <- 100
n_obese <- nrow(x_obese)
n_lean <- nrow(x_lean)
coat.reprod_obese <- vector(length = nRep)
coat.reprod_lean <- vector(length = nRep)
coat.corr.obese.boot.binary <- matrix(0, p, p)
coat.corr.lean.boot.binary <- matrix(0, p, p)


tecoat.reprod_obese <- vector(length = nRep)
tecoat.reprod_lean <- vector(length = nRep)
tecoat.corr.obese.boot.binary <- matrix(0, p, p)
tecoat.corr.lean.boot.binary <- matrix(0, p, p)

for (i in 1:nRep){
  # bootstrap resampling
  x_obese.boot <- x_obese[sample(n_obese, n_obese, replace = TRUE),]
  x_lean.boot <- x_lean[sample(n_lean, n_lean, replace = TRUE),]
  #####   COAT
  res.coat.obese.boot <-  coat(x_obese.boot,nFoler=5)
  coat.ind_nonzero.obese <- abs(res.coat.obese.boot$corr - diag(diag(res.coat.obese.boot$corr))) >= eps
  coat.nsparse.obese <- sum(coat.ind_true_nonzero.obese & coat.ind_nonzero.obese)
  coat.reprod_obese[i] <- coat.nsparse.obese / sum(coat.ind_true_nonzero.obese)
  res.coat.lean.boot <-  coat(x_lean.boot,nFoler=5)
  coat.ind_nonzero.lean <- abs(res.coat.lean.boot$corr - diag(diag(res.coat.lean.boot$corr))) >= eps
  coat.nsparse.lean <- sum(coat.ind_true_nonzero.lean & coat.ind_nonzero.lean)
  coat.reprod_lean[i] <- coat.nsparse.lean / sum(coat.ind_true_nonzero.lean)
  coat.corr.obese.boot.binary <- coat.corr.obese.boot.binary + coat.ind_nonzero.obese + diag(p)
  coat.corr.lean.boot.binary <- coat.corr.lean.boot.binary + coat.ind_nonzero.lean + diag(p)
 
  #####   tecoat
  res.tecoat.obese.boot <-  comp.te(clr(x_obese.boot))  #####
  tecoat.ind_nonzero.obese <- abs(res.tecoat.obese.boot$Gamma - diag(diag(res.tecoat.obese.boot$Gamma))) >= eps
  tecoat.nsparse.obese <- sum(tecoat.ind_true_nonzero.obese & tecoat.ind_nonzero.obese)
  tecoat.reprod_obese[i] <- tecoat.nsparse.obese / sum(tecoat.ind_true_nonzero.obese)
  res.tecoat.lean.boot  <-  comp.te(clr(x_lean.boot))    #####
  tecoat.ind_nonzero.lean <- abs(res.tecoat.lean.boot$Gamma - diag(diag(res.tecoat.lean.boot$Gamma))) >= eps
  tecoat.nsparse.lean <- sum(tecoat.ind_true_nonzero.lean & tecoat.ind_nonzero.lean)
  tecoat.reprod_lean[i] <- tecoat.nsparse.lean / sum(tecoat.ind_true_nonzero.lean)
  tecoat.corr.obese.boot.binary <- tecoat.corr.obese.boot.binary + tecoat.ind_nonzero.obese + diag(p)
  tecoat.corr.lean.boot.binary <- tecoat.corr.lean.boot.binary + tecoat.ind_nonzero.lean + diag(p)
}
###################################################
stab.coat.obese <- mean(coat.reprod_obese)
stab.coat.lean <- mean(coat.reprod_lean)


stab.tecoat.obese <- mean(tecoat.reprod_obese)
stab.tecoat.lean <- mean(tecoat.reprod_lean)
################################################
coat.corr.final.obese <- res.coat.obese$corr
coat.corr.final.obese[which(coat.corr.obese.boot.binary < 85)] <- 0
coat.corr.final.lean <- res.coat.lean$corr
coat.corr.final.lean[which(coat.corr.lean.boot.binary < 85)] <- 0


tecoat.corr.final.obese <- res.tecoat.obese$Gamma
tecoat.corr.final.obese[which(tecoat.corr.obese.boot.binary < 85)] <- 0
tecoat.corr.final.lean <- res.tecoat.lean$Gamma
tecoat.corr.final.lean[which(tecoat.corr.lean.boot.binary < 85)] <- 0
###################################################################
coat.edgeP.obese <- length(which(coat.corr.final.obese - diag(diag(coat.corr.final.obese)) >= eps))/2
coat.edgeP.lean <- length(which(coat.corr.final.lean - diag(diag(coat.corr.final.lean)) >= eps))/2
coat.edgeN.obese <- length(which(coat.corr.final.obese - diag(diag(coat.corr.final.obese)) <= -eps))/2
coat.edgeN.lean <- length(which(coat.corr.final.lean - diag(diag(coat.corr.final.lean)) <= -eps))/2


tecoat.edgeP.obese <- length(which(tecoat.corr.final.obese - diag(diag(tecoat.corr.final.obese)) >= eps))/2
tecoat.edgeP.lean <- length(which(tecoat.corr.final.lean - diag(diag(tecoat.corr.final.lean)) >= eps))/2
tecoat.edgeN.obese <- length(which(tecoat.corr.final.obese - diag(diag(tecoat.corr.final.obese)) <= -eps))/2
tecoat.edgeN.lean <- length(which(tecoat.corr.final.lean - diag(diag(tecoat.corr.final.lean)) <= -eps))/2

#########################################################################

lean.net.coat <- coat.corr.final.lean
obese.net.coat <- coat.corr.final.obese


lean.net.tecoat <- tecoat.corr.final.lean
obese.net.tecoat <- tecoat.corr.final.obese

######################################################
lean.net.coat<-lean.net.coat-diag(diag(lean.net.coat))
obese.net.coat<-obese.net.coat-diag(diag(obese.net.coat))
lean.net.tecoat<-lean.net.tecoat-diag(diag(lean.net.tecoat))
obese.net.tecoat<-obese.net.tecoat-diag(diag(obese.net.tecoat))
Groups<-list("Actinobacteria"=1,"Bacteroidetes"=c(2:9),"Firmicutes"=c(10:37),
"Proteobacteria"=c(38:40))
micronames <- c("Eggerthella","Bacteroides","Barnesiella",
"Butyricimonas","Odoribacter","Parabacteroides","Paraprevotella","Prevotella",
"Alistipes","Gemella","Granulicatella","Lactobacillus","Streptococcus",
"Clostridium","Anaerofustis","Eubacterium","Anaerovorax","Mogibacterium",
"Blautia","Coprococcus","Dorea","Roseburia","Anaerotruncus","Butyricicoccus",
"Faecalibacterium","Oscillibacter","Ruminococcus","Subdoligranulum","Acidaminococcus",
"Dialister","Megasphaera","Phascolarctobacterium","Veillonella","Catenibacterium",
"Coprobacillus","Holdemania","Turicibacter","Parasutterella","Sutterella","Oxalobacter")
colnames(lean.net.coat)<-colnames(obese.net.coat)<-micronames
colnames(lean.net.tecoat)<-colnames(obese.net.tecoat)<-micronames
############################################################
#delete.lean.order <- c(3,4,5,9,13,14,17,21,24,26,27,28,32) # remain 27
#delete.obese.order <- c(13,17,19,20,21,22,23,27,28,30,36,38)  # remain 28
#phyla.lean <- list("Actinobacteria"=1,"Bacteroidetes"=c(2:5),
#                   "Firmicutes"=c(6:24),"Proteobacteria"=c(25:27))
#phyla.obese <- list("Actinobacteria"=1,"Bacteroidetes"=c(2:9),
#                    "Firmicutes"=c(10:26),"Proteobacteria"=c(27:28))
#genera.lean.names <- c("Eggerthella","Bacteroides","Parabacteroides","Paraprevotella",
#"Prevotella","Gemella","Granulicatella","Lactobacillus","Anaerofustis","Eubacterium",
#"Mogibacterium","Blautia","Coprococcus","Roseburia","Anaerotruncus","Faecalibacterium",
#"Acidaminococcus","Dialister","Megasphaera","Veillonella","Catenibacterium",
#"Coprobacillus","Holdemania","Turicibacter","Parasutterella","Sutterella","Oxalobacter")
#genera.obese.names <- c("Eggerthella","Bacteroides","Barnesiella",
#"Butyricimonas","Odoribacter","Parabacteroides","Paraprevotella","Prevotella",
#"Alistipes","Gemella","Granulicatella","Lactobacillus",
#"Clostridium","Anaerofustis","Eubacterium","Mogibacterium",
#"Butyricicoccus",
#"Faecalibacterium","Oscillibacter","Acidaminococcus",
#"Megasphaera","Phascolarctobacterium","Veillonella","Catenibacterium",
#"Coprobacillus","Turicibacter","Sutterella","Oxalobacter")

############################################################

qgraph(lean.net.coat,shape='circle',posCol='red',groups=Groups,
       negCol='green',layout='spring',label.cex=1.5,vsize=5,
       title='COAT-lean',legend=TRUE,borders=FALSE,palette="ggplot2",
       legend.cex=0.4,GLratio=6)
qgraph(obese.net.coat,shape='circle',posCol='red',groups=Groups,
       negCol='green',layout='spring',label.cex=1.5,vsize=5,
       title='COAT-obese',legend=TRUE,borders=FALSE,palette="ggplot2",
       legend.cex=0.4,GLratio=6)

############################################################

qgraph(lean.net.tecoat,shape='circle',posCol='red',groups=Groups,
       negCol='green',layout='spring',label.cex=1.5,vsize=5,
       title='OUR-lean',legend=TRUE,borders=FALSE,palette="ggplot2",
       legend.cex=0.4,GLratio=6)
qgraph(obese.net.tecoat,shape='circle',posCol='red',groups=Groups,
       negCol='green',layout='spring',label.cex=1.5,vsize=5,
       title='OUR-obese',legend=TRUE,borders=FALSE,palette="ggplot2",
       legend.cex=0.4,GLratio=6)


############################################################

#qgraph(lean.net.tecoat[-delete.lean.order,-delete.lean.order],shape='circle',posCol='red',
#       groups=phyla.lean,negCol='green',label.cex= 2.0,
#       layout='spring',vsize=5,title='OUR-lean',
#       legend=TRUE,borders=FALSE,palette="ggplot2",
#       legend.cex=0.35,GLratio=5)
#qgraph(obese.net.tecoat[-delete.obese.order,-delete.obese.order],shape='circle',posCol='red',
#       groups=phyla.obese,negCol='green',label.cex= 2.0,
#       layout='spring',vsize=5,title='OUR-obese',
#       legend=TRUE,borders=FALSE,palette="ggplot2",
#       legend.cex=0.35,GLratio=5)


############################################################


