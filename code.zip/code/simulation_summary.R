require(ROCR)
require(glmnet)
require(MCMCpack)
require(MASS)
require(corpcor)
require(compositions)
require(foreach)
require(parallel)
require(doParallel)

rm(list = ls())



#---------------------------------------------------------------------------------------------------------
#  Correlation estimation and evaluation
#  Input:
#     ns       ------ number of seed, be used in set.seed()
#     n        ------ number of observations
#     p        ------ dimension of variables
#     modelCov  -------- 1-band cov; 2-band and identity cov; 3-AR and identity cov.
#     DistType -------- 1-normal; 2-t5 distribution; 3-t2.5 distribution; 4-\phi ~ F(2,4)
#     mu       -------- mean vector. If NULL, we set it to be i.i.d. Unif(0, 10).
#     coat     ------- If true, we compute the result of coat method.
#     heavycoat ------- If true, we compute the result of heavycoat method, where the last column will be deleted.
#     rcec     ------- If true, we compute the result of rcec method.
#     rsce     ------- If true, we compute the result of rsce method.
#  Output:
#     Res
#---------------------------------------------------------------------------------------------------------


Process <- function(ns, n, p, modelCov, DistType, mu = NULL,
                     coat = T, heavycoat = T, rcec = T, rsce = F){
  source("coat.R")
  source("generate_functions.R")
  source("tecoat.R")
  source("Huber.R")
  source("rcec.R")
  source("heavycoat.R")
  set.seed(20211123 + 100*ns)
  
  Dat = GenerateData(n, p, modelCov, DistType, mu)
  X = Dat$X; W = Dat$W; sigma = Dat$sigma
  logW = log(W)
  
  Res = NULL;names = NULL
  
  # tecoat
  tic = proc.time()
  res.tecoat <- comp.te(clr(X))
  toc = proc.time() - tic
  time = toc[3]
  
  index.min = res.tecoat$index.min
  
  corr.tecoat <- res.tecoat$Gamma
  eva.tecoat = Corr.Evaluate(corr.tecoat, sigma)
  Res = eva.tecoat$evaluate
  methods = "tecoat"
  metrics.names = eva.tecoat$names
  
  # coat
  if(coat){
    tic = proc.time()
    res.coat <- coat(X, soft = 1)
    toc = proc.time() - tic
    time = c(time, toc[3])
    
    index.min = c(index.min, res.coat$index.min)
    
    corr.coat <- res.coat$corr
    eva.coat = Corr.Evaluate(corr.coat, sigma)
    Res = cbind(Res, eva.coat$evaluate)
    methods = c(methods, "coat")
  }
  
  # rcec
  if(rcec){
    tic = proc.time()
    res.rcec = rcec(X)
    toc = proc.time() - tic
    time = c(time, toc[3])
    
    index.min = c(index.min, res.rcec$index.min)
    
    corr.rcec = res.rcec$corr
    eva.rcec = Corr.Evaluate(corr.rcec, sigma)
    Res = cbind(Res, eva.rcec$evaluate)
    methods = c(methods, "rcec")
  }
  
  # rsce(Huber, do not compare it here)
  if(rsce){
    tic = proc.time()
    res.rsce = rsce(X)
    toc = proc.time() - tic
    time = c(time, toc[3])
    
    index.min = c(index.min, res.rsce$index.min)
    
    eva.rsce = Corr.Evaluate(res.rsce$corr, sigma)
    Res = cbind(Res, eva.rsce$evaluate)
    methods = c(methods, "rsce")
  }
  
  # heavycoat with clrX[,-p]
  if(heavycoat){
    sigma.minus.p = sigma[1:(p-1), 1:(p-1)]
    clrX <- log(X) - rowSums(log(X)) %*%matrix(1,1,p) / p

    tic = proc.time()
    res.heavycoat = Heavycoat(clrX[,-p], nFolder = 5)
    toc = proc.time() - tic
    time = c(time, toc[3])
    index.min = c(index.min, res.heavycoat$index.min)
    
    corr.heavycoat = res.heavycoat$corr
    eva.heavycoat = Corr.Evaluate(corr.heavycoat, sigma.minus.p)
    Res = cbind(Res, eva.heavycoat$evaluate)
    methods = c(methods, "heavycoat")
    
    
    # We also need to compute tecoat, coat & rcec with X[,-p]
    corr.tecoat.minus.p <- corr.tecoat[1:(p-1), 1:(p-1)]
    eva.tecoat.minus.p = Corr.Evaluate(corr.tecoat.minus.p, sigma.minus.p)
    Res = cbind(Res, eva.tecoat.minus.p$evaluate)
    methods = c(methods, "tecoat_minus_p")
    time = c(time, time[1])
    index.min = c(index.min, index.min[1])
    
    if(coat){
      corr.coat.minus.p <- corr.coat[1:(p-1), 1:(p-1)]
      eva.coat.minus.p = Corr.Evaluate(corr.coat.minus.p, sigma.minus.p)
      Res = cbind(Res, eva.coat.minus.p$evaluate)
      methods = c(methods, "coat_minus_p")
      time = c(time, time[which(methods == "coat")])
      index.min = c(index.min, index.min[which(methods == "coat")])
    }

    if(rcec){
      corr.rcec.minus.p <- corr.rcec[1:(p-1), 1:(p-1)]
      eva.rcec.minus.p = Corr.Evaluate(corr.rcec.minus.p, sigma.minus.p)
      Res = cbind(Res, eva.rcec.minus.p$evaluate)
      methods = c(methods, "rcec_minus_p")
      time = c(time, time[which(methods == "rcec")])
      index.min = c(index.min, index.min[which(methods == "rcec")])
    }
  }
  
  rownames(Res) = metrics.names
  Res = as.data.frame(t(Res))
  Res$Method = methods
  Res$index.min = index.min
  Res$time = time

  return(Res)
}






#---------------------------------------------------------------------------------------------------------
#                           General framework of parallel
#---------------------------------------------------------------------------------------------------------

library(doParallel)
library(foreach)
cl_num <- 30
cl <- makeCluster(cl_num,outfile="",type="FORK")
registerDoParallel(cl)
simu = 100


n = 100
modelCov = 1
p_seq = c(100, 200, 300)
dist_seq = 1:3


setting = expand.grid(p_seq, dist_seq)


filename = paste("RandomDesign_n",n,"_ModelCov",modelCov,"_Change_p_dist_0729.RData",sep="")

AllRes = list()
AllResMean = list()
AllResSD = list()
for(tt in 1:nrow(setting)){
  p = setting[tt, 1]
  DistType = setting[tt, 2]

  tic = proc.time()
  RES0 = foreach(ns=1:simu,.packages = c("mvtnorm", "LaplacesDemon", "distrEllipse", "ROCR", "glmnet",
                                        "corpcor", "compositions", "fastclime", "pcaPP", "modelr")) %dopar%
    Process(ns, n, p, modelCov, DistType, mu = NULL, coat = T, heavycoat = T, rcec = T, rsce = F)
  toc=proc.time()-tic

  RES0 = do.call(rbind,RES0)
  ResMean = aggregate(subset(RES0,select=-Method),by=list(RES0$Method),mean)
  ResSD = aggregate(subset(RES0,select=-Method),by=list(RES0$Method),sd)

  RES0$n = n
  RES0$p = p
  RES0$modelCov = modelCov
  RES0$DistType = DistType

  ResMean$n = n
  ResMean$p = p
  ResMean$modelCov = modelCov
  ResMean$DistType = DistType

  ResSD$n = n
  ResSD$p = p
  ResSD$modelCov = modelCov
  ResSD$DistType = DistType

  AllRes[[tt]] = RES0
  AllResMean[[tt]] = ResMean
  AllResSD[[tt]] = ResSD

  total_seconds <- toc[3]
  hours <- total_seconds %/% 3600
  minutes <- (total_seconds %% 3600) %/% 60
  seconds <- round(total_seconds %% 60, digits = 3)

  print(paste(paste(tt,"Cost Time:",sep="-"), paste(hours, "hours,", minutes, "minutes, and", seconds, "seconds")))
}

stopCluster(cl)

AllResMean = do.call(rbind,AllResMean)
AllResSD = do.call(rbind,AllResSD)
save(AllRes, AllResMean, AllResSD, file=filename)




